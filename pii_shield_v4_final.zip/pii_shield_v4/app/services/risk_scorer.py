"""
Risk Scorer v2 — Real-World Context-Aware PII Risk Engine
==========================================================

Scoring philosophy:
  1. BASE WEIGHT  — intrinsic sensitivity of each entity type
  2. COMBINATION PENALTIES — certain combinations are exponentially more dangerous
  3. DOCUMENT PROFILE BONUS — detected document type multiplies risk
  4. EXPOSURE MULTIPLIER — more occurrences = more surface area
  5. DPDPA 2023 SEVERITY TAG — maps to Indian Digital Personal Data Protection Act

Real-world threat model:
  CRITICAL (85-100): Identity theft possible. KYC combinable.
  HIGH     (60-84):  Govt biometric or financial document exposed.
  MODERATE (30-59):  Contact / partial financial. Phishing risk.
  SAFE      (<30):   No actionable PII.
"""

import math
from collections import defaultdict
from typing import List, Dict, Set
from app.models.schemas import DetectedEntity, RiskLevel


_BASE_WEIGHT: Dict[str, float] = {
    "AADHAAR_NUMBER":   45,
    "PAN_NUMBER":       38,
    "PASSPORT_NUMBER":  38,
    "VOTER_ID":         32,
    "DRIVING_LICENCE":  30,
    "RATION_CARD":      22,
    "CREDIT_CARD":      35,
    "BANK_ACCOUNT":     28,
    "GST_NUMBER":       18,
    "IFSC_CODE":         5,
    "PHONE_NUMBER":     12,
    "EMAIL_ADDRESS":     9,
    "IP_ADDRESS":        4,
    "URL":               2,
}

_COMBINATION_PENALTIES: List[Dict] = [
    {
        "name": "Full KYC Kit",
        "types": {"AADHAAR_NUMBER", "PAN_NUMBER", "BANK_ACCOUNT"},
        "bonus": 30,
        "threat": "Complete identity theft package — banking KYC bypass possible"
    },
    {
        "name": "Identity Forgery Set",
        "types": {"AADHAAR_NUMBER", "PAN_NUMBER"},
        "bonus": 18,
        "threat": "Tax fraud, SIM registration, account opening without presence"
    },
    {
        "name": "Financial Fraud Kit",
        "types": {"CREDIT_CARD", "PHONE_NUMBER"},
        "bonus": 15,
        "threat": "Card + OTP = complete online fraud chain"
    },
    {
        "name": "Bank Takeover Risk",
        "types": {"BANK_ACCOUNT", "PHONE_NUMBER"},
        "bonus": 12,
        "threat": "UPI registration + bank account = fund transfer risk"
    },
    {
        "name": "Passport + Contact",
        "types": {"PASSPORT_NUMBER", "PHONE_NUMBER"},
        "bonus": 10,
        "threat": "Travel identity + reachability = targeted scam risk"
    },
    {
        "name": "Dual Photo ID",
        "types": {"DRIVING_LICENCE", "AADHAAR_NUMBER"},
        "bonus": 12,
        "threat": "Two photo IDs — impersonation and address proof complete"
    },
    {
        "name": "DL + Contact",
        "types": {"DRIVING_LICENCE", "PHONE_NUMBER"},
        "bonus": 8,
        "threat": "Address + phone — stalking / social engineering risk"
    },
]

_DOCUMENT_PROFILES: List[Dict] = [
    {
        "name": "Full KYC Document Set",
        "required": {"AADHAAR_NUMBER", "PAN_NUMBER"},
        "multiplier": 1.5,
        "icon": "⚠️",
        "color": "#ff0000"
    },
    {
        "name": "Bank Statement",
        "required": {"BANK_ACCOUNT", "IFSC_CODE"},
        "multiplier": 1.35,
        "icon": "🏦",
        "color": "#ff6633"
    },
    {
        "name": "Aadhaar Card",
        "required": {"AADHAAR_NUMBER"},
        "multiplier": 1.3,
        "icon": "🪪",
        "color": "#ff6633"
    },
    {
        "name": "Debit/Credit Card",
        "required": {"CREDIT_CARD"},
        "multiplier": 1.25,
        "icon": "💳",
        "color": "#ff4466"
    },
    {
        "name": "PAN Card",
        "required": {"PAN_NUMBER"},
        "multiplier": 1.2,
        "icon": "📋",
        "color": "#ffaa00"
    },
    {
        "name": "Driving Licence",
        "required": {"DRIVING_LICENCE"},
        "multiplier": 1.15,
        "icon": "🚗",
        "color": "#00aaff"
    },
]

_DPDPA_CATEGORY: Dict[str, str] = {
    "AADHAAR_NUMBER":   "Sensitive Personal Data (DPDPA §2(t))",
    "PAN_NUMBER":       "Sensitive Personal Data — Financial",
    "PASSPORT_NUMBER":  "Sensitive Personal Data — Govt ID",
    "VOTER_ID":         "Personal Data — Govt Identifier",
    "DRIVING_LICENCE":  "Personal Data — Govt Identifier",
    "CREDIT_CARD":      "Sensitive Personal Data — Financial",
    "BANK_ACCOUNT":     "Sensitive Personal Data — Financial",
    "PHONE_NUMBER":     "Personal Data — Contact",
    "EMAIL_ADDRESS":    "Personal Data — Contact",
    "GST_NUMBER":       "Personal Data — Business",
    "RATION_CARD":      "Personal Data — Govt Identifier",
    "IFSC_CODE":        "Non-Personal — Reference Code",
    "IP_ADDRESS":       "Personal Data — Technical",
    "URL":              "Non-Personal — Technical",
}

_REPEAT_WEIGHT: Dict[str, float] = {
    "AADHAAR_NUMBER":    4.0,
    "PAN_NUMBER":        3.0,
    "PASSPORT_NUMBER":   3.0,
    "CREDIT_CARD":       6.0,
    "BANK_ACCOUNT":      4.0,
    "PHONE_NUMBER":      1.5,
    "EMAIL_ADDRESS":     1.2,
    "VOTER_ID":          2.0,
    "DRIVING_LICENCE":   2.5,
    "RATION_CARD":       1.5,
}


def compute_risk_score(entities: List[DetectedEntity]) -> int:
    if not entities:
        return 0

    type_groups: Dict[str, list] = defaultdict(list)
    for e in entities:
        type_groups[str(e.entity_type)].append(e)
    present_types: Set[str] = set(type_groups.keys())

    base_score = 0.0
    for etype, group in type_groups.items():
        base = _BASE_WEIGHT.get(etype, 3)
        repeat = _REPEAT_WEIGHT.get(etype, 1.0)
        count = len(group)
        type_score = base
        if count > 1:
            type_score += repeat * math.log(count + 1, 2)
        base_score += type_score

    combo_bonus = 0.0
    for combo in _COMBINATION_PENALTIES:
        if combo["types"].issubset(present_types):
            combo_bonus += combo["bonus"]

    profile_multiplier = 1.0
    best_match_count = 0
    for profile in _DOCUMENT_PROFILES:
        if profile["required"].issubset(present_types):
            if len(profile["required"]) > best_match_count:
                profile_multiplier = profile["multiplier"]
                best_match_count = len(profile["required"])

    total = (base_score + combo_bonus) * profile_multiplier
    return min(100, int(total))


def classify_risk(score: int) -> RiskLevel:
    if score >= 60:
        return RiskLevel.HIGH
    if score >= 30:
        return RiskLevel.MODERATE
    return RiskLevel.SAFE


def get_risk_details(entities: List[DetectedEntity]) -> dict:
    if not entities:
        return {
            "score": 0,
            "level": "SAFE",
            "is_critical": False,
            "triggered_combos": [],
            "detected_profile": None,
            "dpdpa_categories": [],
            "threat_summary": "No PII detected. Document is safe to share.",
        }

    type_groups: Dict[str, list] = defaultdict(list)
    for e in entities:
        type_groups[str(e.entity_type)].append(e)
    present_types: Set[str] = set(type_groups.keys())

    score = compute_risk_score(entities)
    level = classify_risk(score)
    is_critical = score >= 85

    triggered_combos = []
    for combo in _COMBINATION_PENALTIES:
        if combo["types"].issubset(present_types):
            triggered_combos.append({
                "name": combo["name"],
                "threat": combo["threat"],
                "bonus": combo["bonus"]
            })

    detected_profile = None
    best_match_count = 0
    for profile in _DOCUMENT_PROFILES:
        if profile["required"].issubset(present_types):
            if len(profile["required"]) > best_match_count:
                detected_profile = {
                    "name": profile["name"],
                    "icon": profile["icon"],
                    "color": profile["color"],
                    "multiplier": profile["multiplier"],
                }
                best_match_count = len(profile["required"])

    dpdpa_seen = set()
    dpdpa_categories = []
    for etype in present_types:
        cat = _DPDPA_CATEGORY.get(etype)
        if cat and cat not in dpdpa_seen:
            dpdpa_seen.add(cat)
            dpdpa_categories.append(cat)

    if is_critical:
        threat_summary = "CRITICAL: Multiple identity documents detected. Immediate redaction required."
    elif str(level) == "HIGH":
        threat_summary = "HIGH RISK: Government-grade identity data found. Do not share without redaction."
    elif str(level) == "MODERATE":
        threat_summary = "MODERATE: Financial or contact data present. Review before sharing."
    else:
        threat_summary = "SAFE: Minor or no sensitive data. Low sharing risk."

    return {
        "score": score,
        "level": str(level),
        "is_critical": is_critical,
        "triggered_combos": triggered_combos,
        "detected_profile": detected_profile,
        "dpdpa_categories": dpdpa_categories,
        "threat_summary": threat_summary,
    }
