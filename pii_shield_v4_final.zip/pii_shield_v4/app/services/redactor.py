import re
from typing import List
from app.models.schemas import DetectedEntity


def redact_text(text: str, entities: List[DetectedEntity]) -> str:
    if not entities:
        return text

    sorted_entities = sorted(entities, key=lambda e: e.start, reverse=True)
    chars = list(text)

    for entity in sorted_entities:
        replacement = list(entity.masked_value)
        chars[entity.start:entity.end] = replacement

    return "".join(chars)