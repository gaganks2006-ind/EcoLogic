import io
import logging
from typing import Tuple

logger = logging.getLogger("pii_shield.extractor")


async def extract_text(file_bytes: bytes, mime_type: str, filename: str) -> Tuple[str, str]:
    mime = mime_type.lower()

    if mime == "application/pdf":
        return _extract_pdf(file_bytes)

    if mime in (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/msword",
    ):
        return _extract_docx(file_bytes)

    if mime.startswith("image/"):
        return _extract_image_ocr(file_bytes)

    if mime.startswith("text/"):
        return file_bytes.decode("utf-8", errors="replace"), "plaintext"

    raise ValueError(f"Unsupported file type: {mime_type}")


def _extract_pdf(file_bytes: bytes) -> Tuple[str, str]:
    import fitz
    import pytesseract
    from PIL import Image
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    pages_text = []
    with fitz.open(stream=file_bytes, filetype="pdf") as doc:
        for page in doc:
            text = page.get_text("text").strip()
            if len(text) < 50:
                pix = page.get_pixmap(dpi=100)
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                text = pytesseract.image_to_string(img, lang="eng")
            pages_text.append(text)
    full_text = "\n".join(pages_text)
    logger.info("PDF extracted: %d pages", len(pages_text))
    return full_text, "pdf+ocr"


def _extract_docx(file_bytes: bytes) -> Tuple[str, str]:
    import docx
    buf = io.BytesIO(file_bytes)
    doc = docx.Document(buf)
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text.strip():
                    paragraphs.append(cell.text.strip())
    full_text = "\n".join(paragraphs)
    logger.info("DOCX extracted: %d paragraphs", len(paragraphs))
    return full_text, "docx"


def _extract_image_ocr(file_bytes: bytes) -> Tuple[str, str]:
    import pytesseract
    from PIL import Image
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    buf = io.BytesIO(file_bytes)
    img = Image.open(buf)
    try:
        text = pytesseract.image_to_string(img, lang="eng+hin")
    except Exception:
        text = pytesseract.image_to_string(img, lang="eng")
    logger.info("OCR extracted: %d chars", len(text))
    return text, "ocr"