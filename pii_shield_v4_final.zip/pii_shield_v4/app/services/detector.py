"""
PII Detector — Indian government document edition
==================================================
Detects the following entity types using a combination of regex + checksum
validation + optional Presidio/spaCy NER:

  NATIONAL IDENTITY
  -----------------
  AADHAAR_NUMBER    12-digit biometric ID (Verhoeff checksum)
  PAN_NUMBER        10-char tax identity  (format + type-char validation)
  PASSPORT_NUMBER   Indian passport       (regex + context)
  VOTER_ID          Electoral Photo ID    (EPIC format AA/AAA + 7 digits)
  DRIVING_LICENCE   State/RTO/year/serial (multi-state regex)
  RATION_CARD       State-prefixed card   (context-gated regex)

  FINANCIAL
  ---------
  CREDIT_CARD       Luhn-validated 13-16 digit card numbers
  BANK_ACCOUNT      9-18 digit account numbers (context-gated, Luhn-exempt)
  IFSC_CODE         Bank branch code (4 alpha + 0 + 6 alphanumeric)
  GST_NUMBER        15-char GST with state-code + PAN embed + checksum

  CONTACT
  -------
  PHONE_NUMBER      Indian mobile (+91/91/0 prefix, starts 6-9)
  EMAIL_ADDRESS     Standard email

  TECHNICAL
  ---------
  IP_ADDRESS        IPv4
  URL               Web URLs
"""
from __future__ import annotations
import logging
import re
import time
from typing import List, Optional
from app.config import settings
from app.models.schemas import DetectedEntity, EntityType, MaskSuggestion

logger = logging.getLogger("pii_shield.detector")

_analyzer = None

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Verhoeff checksum tables (Aadhaar)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_V_D = [
    [0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],
    [3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],
    [6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],
    [9,8,7,6,5,4,3,2,1,0],
]
_V_P = [
    [0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],
    [8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],
    [2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8],
]

def _verhoeff_check(raw: str) -> bool:
    digits = re.sub(r'[\s\-]', '', raw)
    if not digits.isdigit() or len(digits) != 12:
        return False
    if digits[0] in ('0', '1'):
        return False
    c = 0
    for i, d in enumerate(reversed(digits)):
        c = _V_D[c][_V_P[i % 8][int(d)]]
    return c == 0


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Luhn checksum (credit cards)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _luhn_check(number: str) -> bool:
    digits = re.sub(r'\D', '', number)
    if len(digits) < 13:
        return False
    total = 0
    reverse = digits[::-1]
    for i, d in enumerate(reverse):
        n = int(d)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GST checksum (last char is a checksum digit/letter)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_GST_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_VALID_GST_STATE_CODES = {
    "01","02","03","04","05","06","07","08","09","10",
    "11","12","13","14","15","16","17","18","19","20",
    "21","22","23","24","25","26","27","28","29","30",
    "31","32","33","34","35","36","37","38","96","97","99",
}

def _gst_checksum_ok(gst: str) -> bool:
    """Validate GST checksum per GSTIN specification."""
    if len(gst) != 15:
        return False
    factor = 2
    total = 0
    for ch in reversed(gst[:-1]):
        if ch not in _GST_CHARS:
            return False
        val = _GST_CHARS.index(ch) * factor
        total += (val // 36) + (val % 36)
        factor = 3 if factor == 2 else 2
    check_idx = (36 - (total % 36)) % 36
    return gst[-1] == _GST_CHARS[check_idx]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PAN type-character validation
# 4th char encodes entity type: P=individual, C=company, H=HUF, etc.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_VALID_PAN_TYPE_CHARS = set("PCHABGJLFT")

def _pan_valid(pan: str) -> bool:
    if len(pan) != 10:
        return False
    if not re.match(r'^[A-Z]{5}[0-9]{4}[A-Z]$', pan):
        return False
    return pan[3] in _VALID_PAN_TYPE_CHARS


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Driving Licence — state RTO codes
# Format: <STATE_CODE><RTO_NO(2)><YEAR(2or4)><SERIAL(6or7)>
# e.g. MH12 2019 1234567  |  DL-01-1234-2021-0000001
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_DL_STATE_CODES = (
    "AN|AP|AR|AS|BR|CG|CH|DD|DL|DN|GA|GJ|HP|HR|JH|JK|KA|KL|LA|LD|MH|ML|"
    "MN|MP|MZ|NL|OD|OR|PB|PY|RJ|SK|TN|TR|TS|UK|UP|UT|WB"
).split("|")

# Two regex variants:
#   A: MH12 2019 1234567  (space/hyphen separated)
#   B: DL011234567890     (compact, no separators)
_DL_RE_A = re.compile(
    r'\b(' + '|'.join(_DL_STATE_CODES) + r')'          # state code
    r'[\s\-]?(\d{2})'                                   # RTO district no
    r'[\s\-]?(\d{4}|\d{2})'                             # year (4 or 2 digit)
    r'[\s\-]?(\d{7}|\d{6})\b',
    re.IGNORECASE,
)
_DL_RE_B = re.compile(
    r'\b(' + '|'.join(_DL_STATE_CODES) + r')'
    r'(\d{2})(\d{4})(\d{7})\b',
    re.IGNORECASE,
)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Voter ID (EPIC) — format: 3 alpha + 7 digits  OR  2 alpha + 7 digits
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_VOTER_RE = re.compile(r'\b[A-Z]{2,3}[0-9]{7}\b')
_VOTER_CONTEXT = re.compile(
    r'voter|epic|electoral|election|voter\s*id|voter\s*card',
    re.IGNORECASE,
)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Ration Card — no single national format; detect by context + digit groups
# Common formats:  NFS-MH-2023-12345678  |  TNPDS-1234567890
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_RATION_CONTEXT = re.compile(
    r'ration\s*card|ration\s*no|ration\s*number|rc\s*no|pds\s*card|nfsa|tnpds|apl|bpl',
    re.IGNORECASE,
)
_RATION_NUMBER_RE = re.compile(r'\b\d{8,12}\b')   # 8-12 digit number near context

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# IFSC Code — 4 alpha (bank) + 0 + 6 alphanumeric (branch)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_IFSC_RE = re.compile(r'\b[A-Z]{4}0[A-Z0-9]{6}\b')

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Bank Account Number — 9 to 18 digits, CONTEXT-GATED (avoid false positives)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_BANK_ACCOUNT_CONTEXT = re.compile(
    r'account\s*(?:no|number|num|#)|a/?c\s*no|bank\s*a/?c|savings\s*account|'
    r'current\s*account|account\s*details',
    re.IGNORECASE,
)
_BANK_ACCOUNT_RE = re.compile(r'\b\d{9,18}\b')

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GST Number — 15 chars: 2-digit state + 10-char PAN + 1 entity + Z + checksum
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_GST_RE = re.compile(
    r'\b(\d{2})'                   # state code (2 digits)
    r'([A-Z]{5}[0-9]{4}[A-Z])'    # PAN (embedded)
    r'([1-9A-Z])'                  # entity number
    r'(Z)'                         # always Z
    r'([0-9A-Z])\b'                # checksum character
)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Helpers
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _normalize_phone(raw: str) -> str:
    digits = re.sub(r'\D', '', raw)
    return digits[-10:] if len(digits) >= 10 else digits

def _is_valid_indian_phone(raw: str) -> bool:
    last10 = _normalize_phone(raw)
    return len(last10) == 10 and last10[0] in ('6', '7', '8', '9')

def _spans_overlap(s1, e1, s2, e2) -> bool:
    return s1 < e2 and s2 < e1

def _context_window(text: str, start: int, end: int, window: int = 80) -> str:
    """Return text ±window chars around the match for context checks."""
    return text[max(0, start - window): min(len(text), end + window)]

def _make_dedup_key(entity_type: str, raw: str) -> tuple:
    if entity_type == "PHONE_NUMBER":
        return (entity_type, _normalize_phone(raw))
    if entity_type == "AADHAAR_NUMBER":
        return (entity_type, re.sub(r'[\s\-]', '', raw))
    if entity_type in ("PAN_NUMBER", "GST_NUMBER", "VOTER_ID",
                       "DRIVING_LICENCE", "IFSC_CODE"):
        return (entity_type, raw.upper().strip())
    return (entity_type, re.sub(r'[\s\-]', '', raw))


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Deduplication
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _deduplicate_entities(entities: List[DetectedEntity]) -> List[DetectedEntity]:
    entities.sort(key=lambda e: e.score, reverse=True)

    seen_keys: set = set()
    pass1: List[DetectedEntity] = []
    for ent in entities:
        key = _make_dedup_key(str(ent.entity_type), ent.masked_value)
        if key not in seen_keys:
            seen_keys.add(key)
            pass1.append(ent)

    kept: List[DetectedEntity] = []
    for ent in pass1:
        overlaps = any(
            str(k.entity_type) == str(ent.entity_type) and
            _spans_overlap(k.start, k.end, ent.start, ent.end)
            for k in kept
        )
        if not overlaps:
            kept.append(ent)
    return kept


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Presidio engine (lazy-loaded)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _get_analyzer():
    global _analyzer
    if _analyzer is not None:
        return _analyzer

    from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer
    from presidio_analyzer.nlp_engine import NlpEngineProvider

    provider = NlpEngineProvider(nlp_configuration={
        "nlp_engine_name": "spacy",
        "models": [{"lang_code": "en", "model_name": settings.SPACY_MODEL}],
    })
    nlp_engine = provider.create_engine()

    passport_recognizer = PatternRecognizer(
        supported_entity="PASSPORT_NUMBER",
        patterns=[Pattern("Passport", r"\b[A-PR-WY][1-9]\d{5}[1-9]\b", 0.85)],
        context=["passport", "travel document", "passport no", "passport number"],
    )

    mobile_recognizer = PatternRecognizer(
        supported_entity="PHONE_NUMBER",
        patterns=[
            Pattern("Indian Mobile", r"\b(?:(?:\+91|91)[\s\-]?|0)?([6-9]\d{9})\b", 0.75)
        ],
        context=["mobile", "phone", "contact", "cell", "tel", "mob", "whatsapp"],
    )

    _analyzer = AnalyzerEngine(nlp_engine=nlp_engine, supported_languages=["en"])
    _analyzer.registry.add_recognizer(passport_recognizer)
    _analyzer.registry.add_recognizer(mobile_recognizer)

    logger.info("Presidio AnalyzerEngine ready")
    return _analyzer


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Main detection function
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def detect_pii(text: str) -> List[DetectedEntity]:
    if not text.strip():
        return []

    t0 = time.monotonic()
    normalized = text.upper()
    lines = text.splitlines()
    seen: set = set()
    entities: List[DetectedEntity] = []

    def add(etype: str, score: float, start: int, end: int, masked: str):
        key = _make_dedup_key(etype, masked)
        if key in seen:
            return
        seen.add(key)
        try:
            et = EntityType(etype)
        except ValueError:
            return
        entities.append(DetectedEntity(
            entity_type=et, score=score,
            start=start, end=end,
            line=_find_line(normalized, start, lines),
            masked_value=masked,
        ))

    # ── 1. AADHAAR (Verhoeff) ─────────────────────────────────────────────
    for m in re.finditer(r'\b(\d{4})[\s\-](\d{4})[\s\-](\d{4})\b(?![\s\-]\d{4})', normalized):
        digits = m.group(1) + m.group(2) + m.group(3)
        before = normalized[m.start()-1] if m.start() > 0 else ' '
        after  = normalized[m.end()]     if m.end() < len(normalized) else ' '
        if before.isdigit() or after.isdigit():
            continue
        if not _verhoeff_check(digits):
            continue
        add("AADHAAR_NUMBER", 0.97, m.start(), m.end(),
            f"XXXX XXXX {digits[-4:]}")

    # ── 2. VID (16-digit, silently skip) ─────────────────────────────────
    for m in re.finditer(r'\b(\d{4})[\s\-](\d{4})[\s\-](\d{4})[\s\-](\d{4})\b', normalized):
        digits = re.sub(r'[\s\-]', '', m.group())
        if len(digits) == 16:
            logger.debug("VID detected and skipped: %s…", digits[:4])

    # ── 3. PAN (type-char validated) ──────────────────────────────────────
    for m in re.finditer(r'\b[A-Z]{5}[0-9]{4}[A-Z]\b', normalized):
        raw = m.group()
        if not _pan_valid(raw):
            continue
        add("PAN_NUMBER", 0.95, m.start(), m.end(),
            f"XXXXX{raw[-5:]}")

    # ── 4. GST Number ─────────────────────────────────────────────────────
    for m in _GST_RE.finditer(normalized):
        raw = m.group()
        state_code = m.group(1)
        if state_code not in _VALID_GST_STATE_CODES:
            logger.debug("GST invalid state code %s, skipping", state_code)
            continue
        if not _gst_checksum_ok(raw):
            logger.debug("GST checksum failed for %s, skipping", raw)
            continue
        add("GST_NUMBER", 0.95, m.start(), m.end(),
            f"{raw[:2]}XXXXXXXXXX{raw[-3:]}")

    # ── 5. IFSC Code ──────────────────────────────────────────────────────
    for m in _IFSC_RE.finditer(normalized):
        raw = m.group()
        add("IFSC_CODE", 0.90, m.start(), m.end(),
            f"{raw[:4]}0XXXXXX")

    # ── 6. Voter ID (EPIC) — context-gated ───────────────────────────────
    for m in _VOTER_RE.finditer(normalized):
        raw = m.group()
        ctx = _context_window(normalized, m.start(), m.end(), window=100)
        if not _VOTER_CONTEXT.search(ctx):
            logger.debug("Voter ID candidate %s skipped — no context", raw)
            continue
        add("VOTER_ID", 0.88, m.start(), m.end(),
            f"{raw[:3]}XXXXXXX")

    # ── 7. Driving Licence ───────────────────────────────────────────────
    for pattern in (_DL_RE_A, _DL_RE_B):
        for m in pattern.finditer(normalized):
            raw = m.group().upper()
            state = m.group(1).upper()
            if state not in _DL_STATE_CODES:
                continue
            add("DRIVING_LICENCE", 0.87, m.start(), m.end(),
                f"{state}XX-XXXX-XXXXXXX")

    # ── 8. Ration Card — strong context gate ──────────────────────────────
    for ctx_m in _RATION_CONTEXT.finditer(normalized):
        # Look for a digit sequence within 120 chars of the context keyword
        search_zone = normalized[ctx_m.end(): ctx_m.end() + 120]
        for num_m in _RATION_NUMBER_RE.finditer(search_zone):
            abs_start = ctx_m.end() + num_m.start()
            abs_end   = ctx_m.end() + num_m.end()
            raw = num_m.group()
            add("RATION_CARD", 0.82, abs_start, abs_end,
                f"XXXX{raw[-4:]}")

    # ── 9. Bank Account — context gate ────────────────────────────────────
    for ctx_m in _BANK_ACCOUNT_CONTEXT.finditer(normalized):
        search_zone = normalized[ctx_m.end(): ctx_m.end() + 100]
        for num_m in _BANK_ACCOUNT_RE.finditer(search_zone):
            raw = num_m.group()
            abs_start = ctx_m.end() + num_m.start()
            abs_end   = ctx_m.end() + num_m.end()
            # Quick sanity: not already captured as Aadhaar
            if any(_spans_overlap(e.start, e.end, abs_start, abs_end) and
                   str(e.entity_type) == "AADHAAR_NUMBER"
                   for e in entities):
                continue
            add("BANK_ACCOUNT", 0.85, abs_start, abs_end,
                f"XXXXXXXX{raw[-4:]}")

    # ── 10. Presidio — credit card, phone, email, IP, passport ──────────
    analyzer = _get_analyzer()
    try:
        results = analyzer.analyze(
            text=normalized,
            entities=["CREDIT_CARD", "PHONE_NUMBER", "EMAIL_ADDRESS",
                      "IP_ADDRESS", "PASSPORT_NUMBER"],
            language="en",
            score_threshold=0.75,
        )
    except Exception as exc:
        logger.error("Presidio analysis failed: %s", exc)
        results = []

    aadhaar_spans = [(e.start, e.end) for e in entities
                     if str(e.entity_type) == "AADHAAR_NUMBER"]

    for r in results:
        raw = normalized[r.start:r.end].strip()

        if r.entity_type == "PHONE_NUMBER":
            if not _is_valid_indian_phone(raw):
                continue
            if any(a0 <= r.start and r.end <= a1 for a0, a1 in aadhaar_spans):
                continue

        if r.entity_type == "CREDIT_CARD":
            if not _luhn_check(raw):
                continue

        key = _make_dedup_key(r.entity_type, raw)
        if key in seen:
            continue
        seen.add(key)
        try:
            etype = EntityType(r.entity_type)
        except ValueError:
            continue
        entities.append(DetectedEntity(
            entity_type=etype,
            score=round(r.score, 3),
            start=r.start, end=r.end,
            line=_find_line(normalized, r.start, lines),
            masked_value=_mask_value(raw, r.entity_type),
        ))

    # ── 11. Final dedup ───────────────────────────────────────────────────
    entities = _deduplicate_entities(entities)

    logger.info("Detected %d unique entities in %dms",
                len(entities), int((time.monotonic() - t0) * 1000))
    return entities


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Mask helpers
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _mask_value(raw: str, entity_type: str) -> str:
    raw = raw.strip()
    digits = re.sub(r'\D', '', raw)

    if entity_type == "AADHAAR_NUMBER":
        d = re.sub(r'[\s\-]', '', raw)
        return f"XXXX XXXX {d[-4:]}"
    if entity_type == "PAN_NUMBER":
        return f"XXXXX{raw[-5:]}" if len(raw) >= 5 else "XXXXXXXXXX"
    if entity_type == "GST_NUMBER":
        return f"{raw[:2]}XXXXXXXXXX{raw[-3:]}" if len(raw) == 15 else "XXXXXXXXXXXXXXX"
    if entity_type == "IFSC_CODE":
        return f"{raw[:4]}0XXXXXX"
    if entity_type == "VOTER_ID":
        return f"{raw[:3]}XXXXXXX"
    if entity_type == "DRIVING_LICENCE":
        parts = raw.split()
        state = parts[0][:2] if parts else "XX"
        return f"{state}XX-XXXX-XXXXXXX"
    if entity_type == "RATION_CARD":
        return f"XXXX{raw[-4:]}" if len(raw) >= 4 else "XXXXXXXXXXXX"
    if entity_type == "BANK_ACCOUNT":
        return f"XXXXXXXX{digits[-4:]}" if len(digits) >= 4 else "XXXXXXXXXXXXXXXXXX"
    if entity_type == "CREDIT_CARD":
        return f"XXXX XXXX XXXX {digits[-4:]}" if len(digits) >= 4 else "XXXX XXXX XXXX XXXX"
    if entity_type == "PHONE_NUMBER":
        last10 = _normalize_phone(raw)
        return f"XXXXXX{last10[-4:]}" if len(last10) >= 4 else "XXXXXXXXXX"
    if entity_type == "EMAIL_ADDRESS":
        parts = raw.split("@")
        if len(parts) == 2:
            return f"{parts[0][:2]}****@{parts[1]}"
        return "****@****.***"
    if entity_type == "PASSPORT_NUMBER":
        return f"{raw[0]}XXXXXXX" if raw else "XXXXXXXX"
    if len(raw) <= 4:
        return "*" * len(raw)
    return "X" * (len(raw) - 4) + raw[-4:]


def _get_mask_pattern(entity_type: str):
    patterns = {
        "AADHAAR_NUMBER":  (r"\b\d{4}[\s-]\d{4}[\s-]\d{4}\b",              "XXXX XXXX ####"),
        "PAN_NUMBER":      (r"\b[A-Z]{5}[0-9]{4}[A-Z]\b",                  "XXXXX#####"),
        "GST_NUMBER":      (r"\b\d{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b", "XX##########Z#"),
        "VOTER_ID":        (r"\b[A-Z]{2,3}[0-9]{7}\b",                     "XXX#######"),
        "DRIVING_LICENCE": (r"\b[A-Z]{2}\d{2}[\s\-]?\d{4}[\s\-]?\d{7}\b", "XX##-####-#######"),
        "RATION_CARD":     (r"\b\d{8,12}\b",                               "XXXX########"),
        "IFSC_CODE":       (r"\b[A-Z]{4}0[A-Z0-9]{6}\b",                   "####0######"),
        "BANK_ACCOUNT":    (r"\b\d{9,18}\b",                               "XXXXXXXX####"),
        "PHONE_NUMBER":    (r"\b(?:(?:\+91|91)[\s\-]?|0)?([6-9]\d{9})\b",  "XXXXXX####"),
        "EMAIL_ADDRESS":   (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "**@***.***"),
        "CREDIT_CARD":     (r"\b(?:\d[ -]?){13,16}\b",                     "XXXX XXXX XXXX ####"),
    }
    return patterns.get(entity_type, (None, "[REDACTED]"))


def build_mask_suggestions(text: str, entities: List[DetectedEntity]) -> List[MaskSuggestion]:
    from collections import defaultdict
    groups: dict = defaultdict(list)
    for e in entities:
        groups[e.entity_type].append(e)
    suggestions = []
    for etype, group in groups.items():
        _, replacement = _get_mask_pattern(str(etype))
        suggestions.append(MaskSuggestion(
            entity_type=str(etype),
            replacement=replacement,
            count=len(group),
        ))
    return suggestions


def _find_line(text: str, offset: int, lines: list) -> Optional[int]:
    pos = 0
    for i, line in enumerate(lines):
        pos += len(line) + 1
        if offset < pos:
            return i + 1
    return None
