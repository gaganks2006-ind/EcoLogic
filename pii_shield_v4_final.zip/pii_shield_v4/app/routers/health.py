from fastapi import APIRouter
from app.models.schemas import HealthResponse

router = APIRouter()

@router.get("/health", response_model=HealthResponse)
async def health_check():
    # Check Presidio
    try:
        from presidio_analyzer import AnalyzerEngine
        presidio_ready = True
    except Exception:
        presidio_ready = False

    # Check OCR
    try:
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
        pytesseract.get_tesseract_version()
        ocr_available = True
    except Exception:
        ocr_available = False

    return HealthResponse(
        status="ok",
        version="1.0.0",
        spacy_model="en_core_web_sm",
        presidio_ready=presidio_ready,
        ocr_available=ocr_available,
        stateless_mode=True,
        dpdp_compliant=True,
    )