import io
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from app.services.extractor import extract_text
from app.services.detector import detect_pii
from app.services.redactor import redact_text
from app.config import settings

router = APIRouter()

@router.post("/redact")
async def redact_file(file: UploadFile = File(...)):

    if file.content_type not in settings.ALLOWED_MIME_TYPES:
        raise HTTPException(status_code=415, detail=f"Unsupported file type: {file.content_type}")

    file_bytes = await file.read()

    if len(file_bytes) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"File too large. Max size is {settings.MAX_UPLOAD_SIZE_MB}MB")

    try:
        text, method = await extract_text(file_bytes, file.content_type, file.filename)
    except ValueError as e:
        raise HTTPException(status_code=415, detail=str(e))

    entities = detect_pii(text)
    redacted_text = redact_text(text, entities)

    mime = file.content_type.lower()

    # Return redacted PDF
    if mime == "application/pdf":
        output = _build_redacted_pdf(file_bytes, entities, text)
        return StreamingResponse(
            io.BytesIO(output),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=redacted_{file.filename}"}
        )

    # Return redacted image
    if mime.startswith("image/"):
        output, out_mime = _build_redacted_image(file_bytes, entities, text)
        return StreamingResponse(
            io.BytesIO(output),
            media_type=out_mime,
            headers={"Content-Disposition": f"attachment; filename=redacted_{file.filename}"}
        )

    # DOCX — return redacted plain text wrapped in docx
    if "wordprocessingml" in mime or "msword" in mime:
        output = _build_redacted_docx(redacted_text)
        return StreamingResponse(
            io.BytesIO(output),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f"attachment; filename=redacted_{file.filename}"}
        )

    # Fallback plain text
    return StreamingResponse(
        io.BytesIO(redacted_text.encode("utf-8")),
        media_type="text/plain",
        headers={"Content-Disposition": f"attachment; filename=redacted_{file.filename}.txt"}
    )


def _build_redacted_pdf(file_bytes: bytes, entities, original_text: str) -> bytes:
    import fitz
    import pytesseract
    from PIL import Image, ImageDraw
    import io as _io

    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

    src_doc = fitz.open(stream=file_bytes, filetype="pdf")
    out_doc = fitz.open()

    # Collect all PII words to redact
    pii_words = set()
    for entity in entities:
        raw = original_text[entity.start:entity.end].strip()
        for w in raw.split():
            cleaned = w.strip(".,;:()[]{}'\"-").upper()
            if len(cleaned) >= 3:
                pii_words.add(cleaned)

    for page in src_doc:
        # Render page to image
        pix = page.get_pixmap(dpi=100)
        img_bytes = pix.tobytes("png")
        img = Image.open(_io.BytesIO(img_bytes)).convert("RGB")
        draw = ImageDraw.Draw(img)

        # OCR to get word bounding boxes
        ocr_data = pytesseract.image_to_data(
            img,
            output_type=pytesseract.Output.DICT,
            config="--psm 6"
        )

        # Black out matching words
        for i in range(len(ocr_data["text"])):
            word = ocr_data["text"][i].strip(".,;:()[]{}'\"-").upper()
            if not word or len(word) < 3:
                continue
            if word in pii_words or any(
                (len(p) >= 4 and (word in p or p in word))
                for p in pii_words
            ):
                x = ocr_data["left"][i]
                y = ocr_data["top"][i]
                w = ocr_data["width"][i]
                h = ocr_data["height"][i]
                if w > 0 and h > 0:
                    draw.rectangle([x-2, y-2, x+w+2, y+h+2], fill=(0, 0, 0))

        # Save redacted image as PNG, embed into new PDF page
        out_img_buf = _io.BytesIO()
        img.save(out_img_buf, format="PNG")
        out_img_buf.seek(0)

        # Create new PDF page same size as original
        page_rect = page.rect
        new_page = out_doc.new_page(width=page_rect.width, height=page_rect.height)

        # Insert image directly (not show_pdf_page)
        new_page.insert_image(new_page.rect, stream=out_img_buf.read())

    output = out_doc.tobytes()
    out_doc.close()
    src_doc.close()
    return output

def _build_redacted_image(file_bytes: bytes, entities, original_text: str):
    import pytesseract
    from PIL import Image, ImageDraw
    import io as _io

    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

    img = Image.open(_io.BytesIO(file_bytes)).convert("RGB")
    draw = ImageDraw.Draw(img)

    # Get word-level bounding boxes from OCR
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)

    for entity in entities:
        raw_value = original_text[entity.start:entity.end].strip()
        words_to_redact = raw_value.split()

        for i, word in enumerate(data["text"]):
            if word.strip() in words_to_redact:
                x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
                draw.rectangle([x, y, x + w, y + h], fill=(0, 0, 0))

    out_buf = _io.BytesIO()
    img.save(out_buf, format="PNG")
    return out_buf.getvalue(), "image/png"


def _build_redacted_docx(redacted_text: str) -> bytes:
    import docx
    import io as _io

    doc = docx.Document()
    for line in redacted_text.splitlines():
        doc.add_paragraph(line)

    buf = _io.BytesIO()
    doc.save(buf)
    return buf.getvalue()