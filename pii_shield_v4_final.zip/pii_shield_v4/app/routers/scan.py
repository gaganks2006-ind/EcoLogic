import time
from fastapi import APIRouter, UploadFile, File, HTTPException
from app.models.schemas import ScanResult
from app.services.extractor import extract_text
from app.services.detector import detect_pii, build_mask_suggestions
from app.services.risk_scorer import compute_risk_score, classify_risk, get_risk_details
from app.config import settings

router = APIRouter()

@router.post("/scan", response_model=ScanResult)
async def scan_file(file: UploadFile = File(...)):
    t0 = time.monotonic()

    if file.content_type not in settings.ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type: {file.content_type}"
        )

    file_bytes = await file.read()

    if len(file_bytes) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Max size is {settings.MAX_UPLOAD_SIZE_MB}MB"
        )

    try:
        text, method = await extract_text(file_bytes, file.content_type, file.filename)
    except ValueError as e:
        raise HTTPException(status_code=415, detail=str(e))

    entities = detect_pii(text)
    risk_score = compute_risk_score(entities)
    risk_level = classify_risk(risk_score)
    risk_details = get_risk_details(entities)
    suggestions = build_mask_suggestions(text, entities)

    processing_ms = int((time.monotonic() - t0) * 1000)

    result = ScanResult(
        filename=file.filename,
        file_size_bytes=len(file_bytes),
        mime_type=file.content_type,
        extraction_method=method,
        risk_score=risk_score,
        risk_level=risk_level,
        entity_count=len(entities),
        entities=entities,
        mask_suggestions=suggestions,
        processing_ms=processing_ms,
    )

    # Attach extended risk details as extra fields
    result_dict = result.dict()
    result_dict["risk_details"] = risk_details
    return result_dict
