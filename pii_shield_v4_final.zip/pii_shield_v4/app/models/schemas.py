from __future__ import annotations
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


class RiskLevel(str, Enum):
    SAFE     = "SAFE"
    MODERATE = "MODERATE"
    HIGH     = "HIGH"


class EntityType(str, Enum):
    # ── Biometric / National Identity ──
    AADHAAR_NUMBER   = "AADHAAR_NUMBER"
    PAN_NUMBER       = "PAN_NUMBER"
    PASSPORT_NUMBER  = "PASSPORT_NUMBER"
    VOTER_ID         = "VOTER_ID"           # NEW — EPIC card
    DRIVING_LICENCE  = "DRIVING_LICENCE"    # NEW
    RATION_CARD      = "RATION_CARD"        # NEW

    # ── Financial ──
    CREDIT_CARD      = "CREDIT_CARD"
    BANK_ACCOUNT     = "BANK_ACCOUNT"       # NEW
    IFSC_CODE        = "IFSC_CODE"          # NEW
    GST_NUMBER       = "GST_NUMBER"         # NEW

    # ── Contact ──
    PHONE_NUMBER     = "PHONE_NUMBER"
    EMAIL_ADDRESS    = "EMAIL_ADDRESS"

    # ── NLP (Presidio / spaCy) ──
    PERSON           = "PERSON"
    LOCATION         = "LOCATION"
    ORGANIZATION     = "ORGANIZATION"
    DATE_TIME        = "DATE_TIME"

    # ── Technical ──
    IP_ADDRESS       = "IP_ADDRESS"
    URL              = "URL"


class DetectedEntity(BaseModel):
    entity_type : EntityType
    score       : float = Field(..., ge=0.0, le=1.0)
    start       : int
    end         : int
    line        : Optional[int] = None
    masked_value: str

    class Config:
        use_enum_values = True


class MaskSuggestion(BaseModel):
    entity_type : str
    replacement : str
    count       : int


class ScanResult(BaseModel):
    filename          : str
    file_size_bytes   : int
    mime_type         : str
    extraction_method : str
    risk_score        : int = Field(..., ge=0, le=100)
    risk_level        : RiskLevel
    entity_count      : int
    entities          : List[DetectedEntity]
    mask_suggestions  : List[MaskSuggestion]
    processing_ms     : int
    stateless         : bool = True

    class Config:
        use_enum_values = True


class RedactResult(BaseModel):
    filename               : str
    original_entity_count  : int
    redacted_count         : int
    redacted_text_preview  : str
    stateless              : bool = True


class HealthResponse(BaseModel):
    status         : str
    version        : str
    spacy_model    : str
    presidio_ready : bool
    ocr_available  : bool
    stateless_mode : bool
    dpdp_compliant : bool
