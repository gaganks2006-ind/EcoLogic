from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    APP_NAME: str = "PII Shield Gateway"
    APP_ENV: str = "development"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    ALLOWED_ORIGINS: List[str] = ["*"]

    MAX_UPLOAD_SIZE_MB: int = 20
    ALLOWED_MIME_TYPES: List[str] = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "image/jpeg",
        "image/png",
        "image/tiff",
    ]

    RISK_WEIGHTS: dict = {
        "AADHAAR_NUMBER": 10,
        "PAN_NUMBER": 9,
        "PASSPORT_NUMBER": 9,
        "CREDIT_CARD": 8,
        "PHONE_NUMBER": 5,
        "EMAIL_ADDRESS": 4,
        "PERSON": 3,
        "LOCATION": 2,
        "ORGANIZATION": 1,
    }

    RISK_HIGH_THRESHOLD: int = 30
    RISK_MODERATE_THRESHOLD: int = 10
    SPACY_MODEL: str = "en_core_web_sm"

    class Config:
        env_file = ".env"

settings = Settings()