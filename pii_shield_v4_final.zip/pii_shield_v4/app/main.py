from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import health, scan, redact

app = FastAPI(
    title="PII Shield Gateway",
    description="Stateless PII detection and redaction API for SYMBIOT 2026",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS - allows browser extension to talk to this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(health.router, prefix="/api/v1", tags=["Health"])
app.include_router(scan.router, prefix="/api/v1", tags=["Scan"])
app.include_router(redact.router, prefix="/api/v1", tags=["Redact"])

@app.get("/")
async def root():
    return {
        "message": "PII Shield Gateway is running",
        "docs": "/docs",
        "version": "1.0.0"
    }