import re
from fastapi import HTTPException


ALLOWED_MIME_TYPES = [
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/jpeg",
    "image/png",
    "image/tiff",
]

MAX_SIZE_MB = 20


def validate_file(filename: str, content_type: str, size_bytes: int):
    # Check extension
    allowed_extensions = [".pdf", ".docx", ".jpg", ".jpeg", ".png", ".tiff"]
    ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in allowed_extensions:
        raise HTTPException(
            status_code=415,
            detail=f"File extension '{ext}' is not allowed."
        )

    # Check MIME type
    if content_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"MIME type '{content_type}' is not supported."
        )

    # Check size
    if size_bytes > MAX_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds maximum size of {MAX_SIZE_MB}MB."
        )

    return True