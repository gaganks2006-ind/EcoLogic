const API_BASE = "http://127.0.0.1:8000/api/v1";

const ACCEPTED_TYPES = new Set([
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/msword",
  "image/jpeg","image/png","image/tiff","image/webp",
  "text/plain","text/csv",
]);
const ACCEPTED_LABEL = "PDF, DOCX, JPG, PNG, TIFF, TXT, CSV";

// ── Style injection ──────────────────────────────────────────────────────────
function injectOverlayStyles() {
  if (document.getElementById("pii-shield-styles")) return;
  const style = document.createElement("style");
  style.id = "pii-shield-styles";
  style.textContent = `
    @keyframes pii-spin { to { transform: rotate(360deg); } }
    @keyframes pii-fadein { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }

    #pii-shield-overlay {
      position: fixed; inset: 0; z-index: 2147483647;
      background: rgba(0,0,0,0.82);
      display: flex; align-items: center; justify-content: center;
      font-family: 'Segoe UI', sans-serif;
      backdrop-filter: blur(3px);
    }
    #pii-shield-modal {
      background: #0d0d1c; color: #e0e0e0;
      border-radius: 16px; padding: 24px;
      width: 440px; max-width: 96vw;
      border: 1px solid #1e1e3a;
      box-shadow: 0 0 60px rgba(0,100,200,0.18), 0 0 0 1px #00d4ff11;
      animation: pii-fadein 0.25s ease;
    }
    .pii-header-bar {
      display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;
    }
    #pii-shield-modal h2 {
      color: #00d4ff; font-size: 17px; margin: 0;
      display: flex; align-items: center; gap: 8px;
    }
    .pii-close-btn {
      background: none; border: none; color: #444; font-size: 20px;
      cursor: pointer; padding: 0 4px; transition: color 0.2s;
    }
    .pii-close-btn:hover { color: #ff6b6b; }
    .pii-filename {
      font-size: 11px; color: #444; margin-bottom: 14px;
      font-family: monospace;
    }

    /* ── Riskometer ── */
    .pii-riskometer {
      border-radius: 12px; padding: 16px 16px 12px;
      margin-bottom: 14px;
    }
    .pii-risk-HIGH {
      background: linear-gradient(135deg,#160606,#1e0808);
      border: 1px solid #ff333444; box-shadow: 0 0 20px #ff222211;
    }
    .pii-risk-MODERATE {
      background: linear-gradient(135deg,#160e00,#1e1400);
      border: 1px solid #ffaa0044; box-shadow: 0 0 20px #ffaa0011;
    }
    .pii-risk-SAFE {
      background: linear-gradient(135deg,#03160a,#051e0e);
      border: 1px solid #00ff8844; box-shadow: 0 0 20px #00ff8811;
    }
    .pii-risk-BLOCKED {
      background: #1a0606; border: 1px solid #ff6b6b44;
    }
    .pii-gauge-wrap { display: flex; justify-content: center; margin-bottom: 4px; }
    .pii-risk-label {
      text-align: center; font-size: 15px; font-weight: 800;
      letter-spacing: 2px; text-transform: uppercase; margin-bottom: 4px;
    }
    .pii-risk-msg {
      text-align: center; font-size: 11.5px; color: #666;
      margin-bottom: 10px; line-height: 1.5;
    }

    /* breakdown bars */
    .pii-breakdown { border-top: 1px solid #1e1e3a; padding-top: 10px; }
    .pii-bd-title {
      font-size: 10px; text-transform: uppercase; letter-spacing: 1px;
      color: #3a3a5a; margin-bottom: 7px;
    }
    .pii-bd-row {
      display: flex; align-items: center; gap: 6px; margin-bottom: 5px;
    }
    .pii-bd-type {
      font-size: 10px; color: #666; width: 140px; flex-shrink: 0;
      font-family: 'Courier New', monospace; text-transform: uppercase;
    }
    .pii-bd-bar-wrap {
      flex: 1; height: 5px; background: #12122a; border-radius: 3px; overflow: hidden;
    }
    .pii-bd-bar { height: 100%; border-radius: 3px; transition: width 0.7s cubic-bezier(0.22,1,0.36,1); }
    .pii-bd-count {
      font-size: 10px; font-family: monospace; width: 24px;
      text-align: right; flex-shrink: 0;
    }

    /* entity rows */
    .pii-entities-box {
      background: #0a0a18; border-radius: 8px; padding: 10px;
      margin-bottom: 14px; max-height: 160px; overflow-y: auto;
    }
    .pii-entity-row {
      display: flex; justify-content: space-between; align-items: center;
      padding: 4px 0; border-bottom: 1px solid #ffffff09; font-size: 12px;
    }
    .pii-entity-row:last-child { border-bottom: none; }
    .pii-entity-type { color: #00d4ff; font-weight: 700; font-size: 10.5px; text-transform: uppercase; }
    .pii-entity-masked { color: #ff6b6b; font-family: monospace; font-size: 11px; }
    .pii-entity-line { color: #444; font-size: 10px; }

    /* actions */
    .pii-actions { display: flex; gap: 8px; flex-direction: column; }
    .pii-btn {
      width: 100%; padding: 11px; border: none; border-radius: 8px;
      font-size: 13px; font-weight: 600; cursor: pointer;
      transition: opacity 0.2s, transform 0.1s;
    }
    .pii-btn:active { transform: scale(0.98); }
    .pii-btn:hover { opacity: 0.88; }
    .pii-btn-allow { background: #00d4ff; color: #000; }
    .pii-btn-redact { background: #ff4466; color: #fff; }
    .pii-btn-cancel { background: #17172a; color: #777; border: 1px solid #2a2a44; }

    /* loader */
    .pii-loader { text-align: center; padding: 28px; color: #00d4ff; font-size: 13px; }
    .pii-spinner {
      width: 32px; height: 32px;
      border: 3px solid #00d4ff22; border-top-color: #00d4ff;
      border-radius: 50%; animation: pii-spin 0.8s linear infinite;
      margin: 0 auto 12px;
    }

    .pii-safe-msg { text-align: center; color: #00ff88; font-size: 13px; padding: 8px 0 14px; }
    .pii-blocked-msg { text-align: center; color: #ff4444; font-size: 12px; padding: 6px 0 12px; }
    .pii-format-msg {
      color: #ffaa00; font-size: 12px; text-align: center; margin-bottom: 14px; line-height: 1.6;
    }
  `;
  document.head.appendChild(style);
}

function createOverlay(content) {
  removeOverlay();
  injectOverlayStyles();
  const overlay = document.createElement("div");
  overlay.id = "pii-shield-overlay";
  overlay.innerHTML = `<div id="pii-shield-modal">${content}</div>`;
  document.body.appendChild(overlay);
  return overlay;
}
function removeOverlay() {
  const e = document.getElementById("pii-shield-overlay");
  if (e) e.remove();
}

function riskIcon(level) {
  if (level === "HIGH") return "🔴";
  if (level === "MODERATE") return "🟡";
  return "🟢";
}
function riskColor(score) {
  if (score >= 60) return { primary: "#ff3333", glow: "#ff333366" };
  if (score >= 25) return { primary: "#ffaa00", glow: "#ffaa0066" };
  return { primary: "#00ff88", glow: "#00ff8866" };
}
function riskMessage(score, level) {
  if (level === "HIGH") return "Gov't-grade identity data detected. Immediate action required.";
  if (level === "MODERATE") return "Financial or contact info found. Review before sharing.";
  return "No sensitive data found. Safe to proceed.";
}

const TYPE_WEIGHTS = {
  "VOTER_ID": 30,
  "DRIVING_LICENCE": 28,
  "RATION_CARD": 22,
  "BANK_ACCOUNT": 22,
  "GST_NUMBER": 15,
  "IFSC_CODE": 5,
  "AADHAAR_NUMBER": 40, "PAN_NUMBER": 35, "PASSPORT_NUMBER": 35,
  "CREDIT_CARD": 25, "PHONE_NUMBER": 10, "EMAIL_ADDRESS": 8,
  "IP_ADDRESS": 4, "URL": 2,
};

function buildBreakdown(entities) {
  if (!entities || entities.length === 0) return [];
  const seen = {};
  entities.forEach(e => { seen[e.entity_type] = (seen[e.entity_type] || 0) + 1; });
  return Object.entries(seen)
    .map(([type, count]) => ({ type, count, weight: TYPE_WEIGHTS[type] || 3 }))
    .sort((a, b) => b.weight - a.weight);
}

function buildGaugeSVG(score, color, id) {
  const R = 52, cx = 68, cy = 66;
  const startAngle = 210, sweepAngle = 240;
  function pt(deg, r) {
    const rad = (deg - 90) * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  }
  const s = pt(startAngle, R);
  const trackEnd = pt(startAngle + sweepAngle, R);
  const safeEnd = pt(startAngle + sweepAngle * 25 / 100, R);
  const modEnd = pt(startAngle + sweepAngle * 60 / 100, R);
  const fillDeg = startAngle + (sweepAngle * Math.min(score, 100) / 100);
  const fillEnd = pt(fillDeg, R);
  const largeFill = (sweepAngle * score / 100) > 180 ? 1 : 0;
  const n1 = pt(fillDeg, R - 6);
  const n2 = pt(fillDeg, 12);

  const ticks = [0, 25, 60, 100].map(v => {
    const deg = startAngle + (sweepAngle * v / 100);
    return { o: pt(deg, R + 6), i: pt(deg, R + 1), v, isKey: v === 25 || v === 60 };
  });

  return `<svg width="136" height="98" viewBox="0 0 136 98" xmlns="http://www.w3.org/2000/svg" class="pii-gauge-svg" data-id="${id}">
  <defs>
    <filter id="pg-glow-${id}"><feGaussianBlur stdDeviation="2.5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <filter id="pg-needle-${id}"><feGaussianBlur stdDeviation="2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
  </defs>
  <path d="M ${s.x.toFixed(1)} ${s.y.toFixed(1)} A ${R} ${R} 0 0 1 ${safeEnd.x.toFixed(1)} ${safeEnd.y.toFixed(1)}" fill="none" stroke="#00ff8833" stroke-width="10" stroke-linecap="butt"/>
  <path d="M ${safeEnd.x.toFixed(1)} ${safeEnd.y.toFixed(1)} A ${R} ${R} 0 0 1 ${modEnd.x.toFixed(1)} ${modEnd.y.toFixed(1)}" fill="none" stroke="#ffaa0033" stroke-width="10" stroke-linecap="butt"/>
  <path d="M ${modEnd.x.toFixed(1)} ${modEnd.y.toFixed(1)} A ${R} ${R} 0 0 1 ${trackEnd.x.toFixed(1)} ${trackEnd.y.toFixed(1)}" fill="none" stroke="#ff333333" stroke-width="10" stroke-linecap="butt"/>
  ${ticks.map(t => `<line x1="${t.o.x.toFixed(1)}" y1="${t.o.y.toFixed(1)}" x2="${t.i.x.toFixed(1)}" y2="${t.i.y.toFixed(1)}" stroke="${t.isKey ? '#444' : '#2a2a2a'}" stroke-width="${t.isKey ? 1.5 : 1}"/>`).join("")}
  <path class="pii-gauge-fill-${id}"
        d="M ${s.x.toFixed(1)} ${s.y.toFixed(1)} A ${R} ${R} 0 ${largeFill} 1 ${fillEnd.x.toFixed(1)} ${fillEnd.y.toFixed(1)}"
        fill="none" stroke="${color.primary}" stroke-width="10" stroke-linecap="round"
        filter="url(#pg-glow-${id})"
        style="stroke-dasharray:400;stroke-dashoffset:400;"/>
  <line class="pii-gauge-needle-${id}"
        x1="${n2.x.toFixed(1)}" y1="${n2.y.toFixed(1)}" x2="${n1.x.toFixed(1)}" y2="${n1.y.toFixed(1)}"
        stroke="${color.primary}" stroke-width="2" stroke-linecap="round"
        filter="url(#pg-needle-${id})" opacity="0"/>
  <circle cx="${cx}" cy="${cy}" r="4.5" fill="${color.primary}" opacity="0.9"/>
  <circle cx="${cx}" cy="${cy}" r="2" fill="#0d0d1c"/>
  <text class="pii-gauge-score-${id}" x="${cx}" y="${cy+20}" text-anchor="middle"
        fill="${color.primary}" font-size="20" font-weight="700"
        font-family="'Courier New',monospace" opacity="0">${score}</text>
  <text x="${cx}" y="${cy+30}" text-anchor="middle"
        fill="#333" font-size="7.5" font-family="'Segoe UI',sans-serif">RISK SCORE / 100</text>
</svg>`;
}

function animateGauge(id, score) {
  const fill = document.querySelector(`.pii-gauge-fill-${id}`);
  const needle = document.querySelector(`.pii-gauge-needle-${id}`);
  const scoreText = document.querySelector(`.pii-gauge-score-${id}`);
  if (!fill) return;
  const arcLen = 400 * Math.min(score, 100) / 100;
  fill.style.transition = "none";
  fill.style.strokeDashoffset = "400";
  requestAnimationFrame(() => {
    setTimeout(() => {
      fill.style.transition = "stroke-dashoffset 1.3s cubic-bezier(0.22,1,0.36,1)";
      fill.style.strokeDashoffset = String(400 - arcLen);
      if (needle) { needle.style.transition = "opacity 0.3s ease 0.6s"; needle.style.opacity = "1"; }
      if (scoreText) { scoreText.style.transition = "opacity 0.5s ease 0.9s"; scoreText.style.opacity = "1"; }
    }, 60);
  });
}

function headerBar(title) {
  return `<div class="pii-header-bar">
    <h2>🛡️ ${title}</h2>
    <button class="pii-close-btn" id="pii-hdr-close">✕</button>
  </div>`;
}
function attachHeaderClose() {
  const btn = document.getElementById("pii-hdr-close");
  if (btn) btn.onclick = () => removeOverlay();
}

// ── Riskometer HTML builder ──────────────────────────────────────────────────
function buildRiskometerHTML(score, level, entities, gaugeId) {
  const color = riskColor(score);
  const msg = riskMessage(score, level);
  const breakdown = buildBreakdown(entities);

  const breakdownHTML = breakdown.length > 0 ? `
    <div class="pii-breakdown">
      <div class="pii-bd-title">Risk Contributors</div>
      ${breakdown.map(item => {
        const pct = Math.min(100, Math.round((item.weight / 40) * 100));
        const c = item.weight >= 35 ? "#ff4444" : item.weight >= 20 ? "#ffaa00" : "#00d4ff";
        return `<div class="pii-bd-row">
          <span class="pii-bd-type">${item.type.replace(/_/g," ")}</span>
          <div class="pii-bd-bar-wrap"><div class="pii-bd-bar" style="width:0%;background:${c}" data-target="${pct}"></div></div>
          <span class="pii-bd-count" style="color:${c}">×${item.count}</span>
        </div>`;
      }).join("")}
    </div>
  ` : "";

  return `
    <div class="pii-riskometer pii-risk-${level}">
      <div class="pii-gauge-wrap">${buildGaugeSVG(score, color, gaugeId)}</div>
      <div class="pii-risk-label" style="color:${color.primary}">${riskIcon(level)} ${level} RISK</div>
      <div class="pii-risk-msg">${msg}</div>
      ${breakdownHTML}
    </div>
  `;
}

function startBreakdownAnims() {
  document.querySelectorAll(".pii-bd-bar[data-target]").forEach((bar, i) => {
    setTimeout(() => { bar.style.width = bar.dataset.target + "%"; }, 300 + i * 120);
  });
}

// ── File type guard ──────────────────────────────────────────────────────────
function checkFileType(file) {
  if (ACCEPTED_TYPES.has(file.type || "")) return true;
  createOverlay(`
    ${headerBar("Scan Upload AI")}
    <div class="pii-filename">${file.name}</div>
    <div class="pii-riskometer pii-risk-BLOCKED" style="text-align:center;padding:16px;">
      <div style="font-size:28px;margin-bottom:6px;">⛔</div>
      <div style="font-size:14px;font-weight:700;color:#ff6b6b;">Unsupported File Type</div>
    </div>
    <div class="pii-format-msg">
      <strong>${file.name}</strong> cannot be scanned.<br/>
      Accepted formats: <strong>${ACCEPTED_LABEL}</strong>
    </div>
    <div class="pii-actions">
      <button class="pii-btn pii-btn-cancel" id="pii-cancel-btn">❌ Close</button>
    </div>
  `);
  attachHeaderClose();
  document.getElementById("pii-cancel-btn").onclick = () => removeOverlay();
  return false;
}

// ── Main scan logic ──────────────────────────────────────────────────────────
async function scanAndIntercept(file, inputEl) {
  if (!checkFileType(file)) return;

  createOverlay(`
    ${headerBar("Scan Upload AI")}
    <div class="pii-filename">Scanning: ${file.name}</div>
    <div class="pii-loader">
      <div class="pii-spinner"></div>
      Analyzing file for sensitive data…
    </div>
  `);
  attachHeaderClose();

  let scanData;
  try {
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch(`${API_BASE}/scan`, { method: "POST", body: formData });
    if (!res.ok) throw new Error("Scan failed");
    scanData = await res.json();
  } catch (err) {
    removeOverlay();
    return;
  }

  const level = scanData.risk_level;
  const score = scanData.risk_score;
  const entities = scanData.entities || [];
  const gaugeId = Date.now();

  let entitiesHTML = "";
  if (entities.length === 0) {
    entitiesHTML = `<div class="pii-safe-msg">✅ No sensitive data found</div>`;
  } else {
    entitiesHTML = `<div class="pii-entities-box">` +
      entities.map(e => `
        <div class="pii-entity-row">
          <span class="pii-entity-type">${e.entity_type}</span>
          <span class="pii-entity-masked">${e.masked_value}</span>
          <span class="pii-entity-line">Line ${e.line || "?"}</span>
        </div>
      `).join("") + `</div>`;
  }

  const riskometerHTML = buildRiskometerHTML(score, level, entities, gaugeId);

  // SAFE — auto-upload after 3s
  if (level === "SAFE") {
    let countdown = 3;
    createOverlay(`
      ${headerBar("Scan Upload AI")}
      <div class="pii-filename">${file.name}</div>
      ${riskometerHTML}
      <div class="pii-safe-msg" style="margin-bottom:8px;">
        ✅ File is clean. Uploading in <span id="pii-countdown">3</span>s…
      </div>
      <div class="pii-actions">
        <button class="pii-btn pii-btn-cancel" id="pii-cancel-btn">❌ Cancel Upload</button>
      </div>
    `);
    attachHeaderClose();
    requestAnimationFrame(() => { animateGauge(gaugeId, score); startBreakdownAnims(); });

    let cancelled = false;
    document.getElementById("pii-cancel-btn").onclick = () => { cancelled = true; removeOverlay(); };
    const timer = setInterval(() => {
      countdown--;
      const el = document.getElementById("pii-countdown");
      if (el) el.textContent = countdown;
      if (countdown <= 0) {
        clearInterval(timer);
        if (!cancelled) { removeOverlay(); triggerUpload(inputEl, file); }
      }
    }, 1000);
    return;
  }

  // MODERATE
  if (level === "MODERATE") {
    createOverlay(`
      ${headerBar("Scan Upload AI — Warning")}
      <div class="pii-filename">${file.name}</div>
      ${riskometerHTML}
      ${entitiesHTML}
      <div class="pii-actions">
        <button class="pii-btn pii-btn-redact" id="pii-redact-upload">🔒 Redact PII &amp; Upload</button>
        <button class="pii-btn pii-btn-allow" id="pii-allow-btn">✅ Upload Original Anyway</button>
        <button class="pii-btn pii-btn-cancel" id="pii-cancel-btn">❌ Cancel Upload</button>
      </div>
    `);
    attachHeaderClose();
    requestAnimationFrame(() => { animateGauge(gaugeId, score); startBreakdownAnims(); });
    document.getElementById("pii-redact-upload").onclick = () => redactAndUpload(file, inputEl);
    document.getElementById("pii-allow-btn").onclick = () => { removeOverlay(); triggerUpload(inputEl, file); };
    document.getElementById("pii-cancel-btn").onclick = () => removeOverlay();
    return;
  }

  // HIGH
  if (level === "HIGH") {
    createOverlay(`
      ${headerBar("Scan Upload AI — HIGH RISK")}
      <div class="pii-filename">${file.name}</div>
      ${riskometerHTML}
      ${entitiesHTML}
      <div class="pii-blocked-msg">⛔ Upload blocked. Sensitive identity data detected.</div>
      <div class="pii-actions">
        <button class="pii-btn pii-btn-redact" id="pii-redact-upload">🔒 Redact PII &amp; Upload</button>
        <button class="pii-btn pii-btn-allow" id="pii-allow-btn">⚠️ Upload Original (Risk Accepted)</button>
        <button class="pii-btn pii-btn-cancel" id="pii-cancel-btn">❌ Cancel Upload</button>
      </div>
    `);
    attachHeaderClose();
    requestAnimationFrame(() => { animateGauge(gaugeId, score); startBreakdownAnims(); });
    document.getElementById("pii-redact-upload").onclick = () => redactAndUpload(file, inputEl);
    document.getElementById("pii-allow-btn").onclick = () => { removeOverlay(); triggerUpload(inputEl, file); };
    document.getElementById("pii-cancel-btn").onclick = () => removeOverlay();
  }
}

async function redactAndUpload(originalFile, inputEl) {
  const modal = document.getElementById("pii-shield-modal");
  if (modal) modal.innerHTML = `
    ${headerBar("Scan Upload AI")}
    <div class="pii-loader">
      <div class="pii-spinner"></div>
      Redacting sensitive data…
    </div>
  `;
  attachHeaderClose();
  try {
    const formData = new FormData();
    formData.append("file", originalFile);
    const res = await fetch(`${API_BASE}/redact`, { method: "POST", body: formData });
    if (!res.ok) throw new Error("Redact failed");
    const blob = await res.blob();
    const contentDisposition = res.headers.get("Content-Disposition") || "";
    let redactedName = "redacted_" + originalFile.name;
    const match = contentDisposition.match(/filename=([^;]+)/);
    if (match) redactedName = match[1].replace(/"/g, "").trim();
    const redactedFile = new File([blob], redactedName, { type: blob.type || originalFile.type });
    removeOverlay();
    triggerUpload(inputEl, redactedFile);
  } catch (err) {
    removeOverlay();
    alert("Redaction failed. Uploading original.");
    triggerUpload(inputEl, originalFile);
  }
}

function triggerUpload(inputEl, file) {
  const dt = new DataTransfer();
  dt.items.add(file);
  inputEl._piiShieldBypassed = true;
  inputEl.files = dt.files;
  inputEl.dispatchEvent(new Event("change", { bubbles: true }));
  inputEl.dispatchEvent(new Event("input", { bubbles: true }));
}

function attachToFileInputs() {
  document.querySelectorAll('input[type="file"]').forEach(attachListener);
}

function attachListener(inputEl) {
  if (inputEl._piiShieldAttached) return;
  inputEl._piiShieldAttached = true;
  inputEl.addEventListener("change", async function(e) {
    if (inputEl._piiShieldBypassed) { inputEl._piiShieldBypassed = false; return; }
    const file = inputEl.files[0];
    if (!file) return;
    const dt = new DataTransfer();
    inputEl.files = dt.files;
    await scanAndIntercept(file, inputEl);
  }, true);
}

const observer = new MutationObserver(() => {
  document.querySelectorAll('input[type="file"]:not([data-pii-attached])').forEach(el => {
    el.setAttribute("data-pii-attached", "true");
    attachListener(el);
  });
});
observer.observe(document.body, { childList: true, subtree: true });
attachToFileInputs();
