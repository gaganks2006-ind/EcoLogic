"use strict";
const API_BASE = "http://127.0.0.1:8000/api/v1";

// ── DOM refs ──────────────────────────────────────────────────────────────────
const fileInput      = document.getElementById("fileInput");
const scanBtn        = document.getElementById("scanBtn");
const redactBtn      = document.getElementById("redactBtn");
const exportBtn      = document.getElementById("exportBtn");
const loader         = document.getElementById("loader");
const loaderText     = document.getElementById("loaderText");
const results        = document.getElementById("results");
const riskometer     = document.getElementById("riskometer");
const riskLabel      = document.getElementById("riskLabel");
const riskMessage    = document.getElementById("riskMessage");
const docProfile     = document.getElementById("docProfile");
const combosSection  = document.getElementById("combosSection");
const combosList     = document.getElementById("combosList");
const breakdownSec   = document.getElementById("breakdownSection");
const breakdownList  = document.getElementById("breakdownList");
const statsEl        = document.getElementById("stats");
const entitiesList   = document.getElementById("entitiesList");
const entityCountBadge = document.getElementById("entityCount");
const redactResult   = document.getElementById("redactResult");
const redactedText   = document.getElementById("redactedText");
const uploadArea     = document.getElementById("uploadArea");
const uploadLabel    = document.getElementById("uploadLabel");
const historyList    = document.getElementById("historyList");
const dpdpaInfo      = document.getElementById("dpdpaInfo");

let selectedFile = null;
let lastScanData = null;
let scanHistory  = JSON.parse(localStorage.getItem("pii_history") || "[]");

// ── Tabs ───────────────────────────────────────────────────────────────────────
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
    if (tab.dataset.tab === "history") renderHistory();
    if (tab.dataset.tab === "compliance") renderDPDPA();
  });
});

// ── File selection ─────────────────────────────────────────────────────────────
fileInput.addEventListener("change", e => {
  selectedFile = e.target.files[0];
  if (selectedFile) onFileSelected();
});

uploadArea.addEventListener("dragover", e => { e.preventDefault(); uploadArea.classList.add("drag-over"); });
uploadArea.addEventListener("dragleave", () => uploadArea.classList.remove("drag-over"));
uploadArea.addEventListener("drop", e => {
  e.preventDefault();
  uploadArea.classList.remove("drag-over");
  const f = e.dataTransfer.files[0];
  if (f) { selectedFile = f; onFileSelected(); }
});

function onFileSelected() {
  uploadLabel.textContent = "📄 " + selectedFile.name;
  scanBtn.disabled = false;
  redactBtn.disabled = false;
  results.classList.add("hidden");
  redactResult.classList.add("hidden");
}

// ── Scan ───────────────────────────────────────────────────────────────────────
scanBtn.addEventListener("click", async () => {
  if (!selectedFile) return;
  showLoader("Extracting text…");
  results.classList.add("hidden");
  redactResult.classList.add("hidden");

  const formData = new FormData();
  formData.append("file", selectedFile);

  try {
    setTimeout(() => { loaderText.textContent = "Detecting PII…"; }, 600);
    setTimeout(() => { loaderText.textContent = "Scoring risk…"; }, 1200);

    const response = await fetch(`${API_BASE}/scan`, { method: "POST", body: formData });
    if (!response.ok) {
      const err = await response.json();
      alert("Error: " + (err.detail || "Unknown error"));
      return;
    }
    const data = await response.json();
    lastScanData = data;
    addToHistory(data);
    showResults(data);
    exportBtn.disabled = false;
  } catch (err) {
    alert("Cannot connect to PII Shield server. Make sure it is running on port 8000.");
  } finally {
    hideLoader();
  }
});

// ── Redact ─────────────────────────────────────────────────────────────────────
redactBtn.addEventListener("click", async () => {
  if (!selectedFile) return;
  showLoader("Redacting PII…");
  results.classList.add("hidden");
  redactResult.classList.add("hidden");

  const formData = new FormData();
  formData.append("file", selectedFile);

  try {
    const response = await fetch(`${API_BASE}/redact`, { method: "POST", body: formData });
    if (!response.ok) {
      const err = await response.json();
      alert("Error: " + (err.detail || "Unknown error"));
      return;
    }
    const data = await response.json();
    redactedText.textContent = data.redacted_text_preview || "No text to show.";
    redactResult.classList.remove("hidden");
  } catch (err) {
    alert("Cannot connect to PII Shield server. Make sure it is running on port 8000.");
  } finally {
    hideLoader();
  }
});

// ── Export JSON report ─────────────────────────────────────────────────────────
exportBtn.addEventListener("click", () => {
  if (!lastScanData) return;
  const report = {
    generated_at: new Date().toISOString(),
    tool: "PII Shield v4 — SYMBIOT 2026",
    filename: lastScanData.filename,
    risk_score: lastScanData.risk_score,
    risk_level: lastScanData.risk_level,
    entity_count: lastScanData.entity_count,
    risk_details: lastScanData.risk_details || {},
    entities: (lastScanData.entities || []).map(e => ({
      type: e.entity_type,
      masked: e.masked_value,
      line: e.line,
      confidence: e.score,
    })),
  };
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `pii_report_${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

// ── Copy redacted ──────────────────────────────────────────────────────────────
document.getElementById("copyRedact").addEventListener("click", () => {
  navigator.clipboard.writeText(redactedText.textContent).then(() => {
    const btn = document.getElementById("copyRedact");
    btn.textContent = "✅ Copied!";
    setTimeout(() => { btn.textContent = "📋 Copy"; }, 1500);
  });
});

// ── History ────────────────────────────────────────────────────────────────────
document.getElementById("clearHistory").addEventListener("click", () => {
  scanHistory = [];
  localStorage.setItem("pii_history", "[]");
  renderHistory();
});

function addToHistory(data) {
  scanHistory.unshift({
    name: data.filename,
    score: data.risk_score,
    level: data.risk_level,
    count: data.entity_count,
    time: Date.now(),
    profile: data.risk_details?.detected_profile?.name || null,
  });
  if (scanHistory.length > 20) scanHistory.pop();
  localStorage.setItem("pii_history", JSON.stringify(scanHistory));
}

function renderHistory() {
  if (scanHistory.length === 0) {
    historyList.innerHTML = '<p class="empty-msg">No scan history yet.</p>';
    return;
  }
  historyList.innerHTML = scanHistory.map(h => {
    const color = h.level === "HIGH" ? "#ff4444" : h.level === "MODERATE" ? "#ffaa00" : "#00ff88";
    const ago = timeAgo(h.time);
    return `<div class="history-item">
      <div class="hist-dot ${h.level}"></div>
      <div class="hist-info">
        <div class="hist-name" title="${h.name}">${h.name}</div>
        <div class="hist-meta">${h.count} PII entities · ${h.profile || "Unknown doc"} · ${ago}</div>
      </div>
      <div class="hist-score" style="color:${color}">${h.score}</div>
    </div>`;
  }).join("");
}

function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s/60) + "m ago";
  if (s < 86400) return Math.floor(s/3600) + "h ago";
  return Math.floor(s/86400) + "d ago";
}

// ── DPDPA tab ──────────────────────────────────────────────────────────────────
function renderDPDPA() {
  if (!lastScanData || !lastScanData.risk_details) {
    dpdpaInfo.innerHTML = '<p class="empty-msg">Run a scan to see DPDPA compliance analysis.</p>';
    return;
  }
  const cats = lastScanData.risk_details.dpdpa_categories || [];
  if (cats.length === 0) {
    dpdpaInfo.innerHTML = '<p class="empty-msg">✅ No DPDPA-regulated data found.</p>';
    return;
  }
  dpdpaInfo.innerHTML = cats.map(cat => {
    const isSensitive = cat.includes("Sensitive");
    const isNonPersonal = cat.includes("Non-Personal");
    const dotClass = isSensitive ? "sensitive" : isNonPersonal ? "non-personal" : "personal";
    const riskTag = isSensitive
      ? "Requires explicit consent & breach notification"
      : isNonPersonal
      ? "No DPDPA obligation"
      : "Must have lawful purpose & notice";
    return `<div class="dpdpa-item">
      <div class="dpdpa-dot ${dotClass}"></div>
      <div>
        <div class="dpdpa-text">${cat}</div>
        <div class="dpdpa-category">${riskTag}</div>
      </div>
    </div>`;
  }).join("");
}

// ── Gauge (SVG arc — fixed, no glitch) ────────────────────────────────────────
const CX = 100, CY = 100, R = 72;
const START_DEG = 215, SWEEP = 230;

function deg2rad(d) { return (d - 90) * Math.PI / 180; }

function polarXY(deg, r) {
  const rad = deg2rad(deg);
  return { x: CX + r * Math.cos(rad), y: CY + r * Math.sin(rad) };
}

function arcPath(startDeg, endDeg, r) {
  const s = polarXY(startDeg, r);
  const e = polarXY(endDeg, r);
  const large = (endDeg - startDeg) > 180 ? 1 : 0;
  return `M ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${e.x.toFixed(2)} ${e.y.toFixed(2)}`;
}

function initGauge() {
  const safeDeg  = START_DEG + SWEEP * 0.30;   // 0-30 = safe
  const modDeg   = START_DEG + SWEEP * 0.60;   // 30-60 = moderate
  const endDeg   = START_DEG + SWEEP;

  document.getElementById("zoneSafe").setAttribute("d", arcPath(START_DEG, safeDeg, R));
  document.getElementById("zoneMod" ).setAttribute("d", arcPath(safeDeg,   modDeg,  R));
  document.getElementById("zoneHigh").setAttribute("d", arcPath(modDeg,    endDeg,  R));

  // Tick marks at 0, 30, 60, 100
  const ticks = document.getElementById("gaugeTicks");
  ticks.innerHTML = "";
  [0, 30, 60, 100].forEach(v => {
    const deg = START_DEG + SWEEP * v / 100;
    const o = polarXY(deg, R + 10);
    const i = polarXY(deg, R + 3);
    const lp= polarXY(deg, R + 19);
    const isKey = v === 30 || v === 60;
    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
    line.setAttribute("x1", o.x); line.setAttribute("y1", o.y);
    line.setAttribute("x2", i.x); line.setAttribute("y2", i.y);
    line.setAttribute("stroke", isKey ? "#444" : "#2a2a3a");
    line.setAttribute("stroke-width", isKey ? "1.5" : "1");
    ticks.appendChild(line);

    if (isKey) {
      const txt = document.createElementNS("http://www.w3.org/2000/svg", "text");
      txt.setAttribute("x", lp.x); txt.setAttribute("y", lp.y + 3);
      txt.setAttribute("text-anchor", "middle");
      txt.setAttribute("fill", "#555");
      txt.setAttribute("font-size", "8");
      txt.setAttribute("font-family", "'Courier New', monospace");
      txt.textContent = v;
      ticks.appendChild(txt);
    }
  });
}

let gaugeAnimFrame = null;
let gaugeCurrentScore = 0;

function animateGaugeTo(targetScore, color) {
  if (gaugeAnimFrame) cancelAnimationFrame(gaugeAnimFrame);

  const arc   = document.getElementById("gaugeArc");
  const hub   = document.getElementById("gaugeHub");
  const score = document.getElementById("gaugeScore");
  const start = gaugeCurrentScore;
  const duration = 1100;
  const t0 = performance.now();

  function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

  function frame(now) {
    const elapsed = now - t0;
    const progress = Math.min(1, elapsed / duration);
    const eased = easeOut(progress);
    const current = Math.round(start + (targetScore - start) * eased);

    // Update arc path
    if (current <= 0) {
      arc.removeAttribute("d");
    } else {
      const fillDeg = START_DEG + SWEEP * Math.min(current, 100) / 100;
      arc.setAttribute("d", arcPath(START_DEG, fillDeg, R));
    }

    arc.setAttribute("stroke", color);
    hub.setAttribute("fill", color);
    score.setAttribute("fill", color);
    score.textContent = current;

    if (progress < 1) {
      gaugeAnimFrame = requestAnimationFrame(frame);
    } else {
      gaugeCurrentScore = targetScore;
    }
  }

  gaugeAnimFrame = requestAnimationFrame(frame);
}

// ── showResults ────────────────────────────────────────────────────────────────
function riskColor(score) {
  if (score >= 85) return "#ff1111";
  if (score >= 60) return "#ff4444";
  if (score >= 30) return "#ffaa00";
  return "#00ff88";
}

function riskClass(level, score) {
  if (score >= 85) return "risk-CRITICAL";
  return "risk-" + level;
}

const TYPE_WEIGHTS = {
  "AADHAAR_NUMBER": 45, "PAN_NUMBER": 38, "PASSPORT_NUMBER": 38,
  "VOTER_ID": 32, "DRIVING_LICENCE": 30, "RATION_CARD": 22,
  "CREDIT_CARD": 35, "BANK_ACCOUNT": 28, "GST_NUMBER": 18,
  "IFSC_CODE": 5, "PHONE_NUMBER": 12, "EMAIL_ADDRESS": 9,
  "IP_ADDRESS": 4, "URL": 2,
};

function showResults(data) {
  const score  = data.risk_score;
  const level  = data.risk_level;
  const color  = riskColor(score);
  const detail = data.risk_details || {};
  const entities = data.entities || [];
  const isCritical = score >= 85;

  // Riskometer styling
  riskometer.className = "riskometer " + riskClass(level, score);
  riskLabel.style.color = color;

  const levelText = isCritical ? "⚠️ CRITICAL RISK" :
    level === "HIGH" ? "🔴 HIGH RISK" :
    level === "MODERATE" ? "🟡 MODERATE RISK" : "🟢 SAFE";
  riskLabel.textContent = levelText;
  riskMessage.textContent = detail.threat_summary || "";

  // Document profile badge
  if (detail.detected_profile) {
    const p = detail.detected_profile;
    docProfile.style.display = "inline-block";
    docProfile.style.borderColor = p.color + "44";
    docProfile.style.color = p.color;
    docProfile.textContent = p.icon + " " + p.name + " detected · ×" + p.multiplier.toFixed(1) + " risk";
  } else {
    docProfile.style.display = "none";
  }

  // Animate gauge
  animateGaugeTo(score, color);

  // Threat combinations
  const combos = detail.triggered_combos || [];
  if (combos.length > 0) {
    combosSection.classList.remove("hidden");
    combosList.innerHTML = combos.map(c => `
      <div class="combo-item">
        <span class="combo-bonus">+${c.bonus} pts</span>
        <div class="combo-name">⚡ ${c.name}</div>
        <div class="combo-threat">${c.threat}</div>
      </div>
    `).join("");
  } else {
    combosSection.classList.add("hidden");
  }

  // Breakdown bars
  const typeMap = {};
  entities.forEach(e => { typeMap[e.entity_type] = (typeMap[e.entity_type] || 0) + 1; });
  const breakdown = Object.entries(typeMap)
    .map(([type, count]) => ({ type, count, weight: TYPE_WEIGHTS[type] || 3 }))
    .sort((a, b) => b.weight - a.weight);

  if (breakdown.length > 0) {
    breakdownSec.classList.remove("hidden");
    breakdownList.innerHTML = breakdown.map(item => {
      const pct = Math.min(100, Math.round((item.weight / 45) * 100));
      const c = item.weight >= 38 ? "#ff4444" : item.weight >= 22 ? "#ffaa00" : "#00d4ff";
      return `<div class="breakdown-row">
        <span class="bd-type">${item.type.replace(/_/g," ")}</span>
        <div class="bd-bar-wrap"><div class="bd-bar" style="background:${c}" data-target="${pct}"></div></div>
        <span class="bd-count" style="color:${c}">×${item.count}</span>
      </div>`;
    }).join("");
  } else {
    breakdownSec.classList.add("hidden");
  }

  // Stats
  statsEl.textContent = `${data.entity_count} PII entities · ${data.filename} · ${data.processing_ms}ms`;

  // Entity count badge
  entityCountBadge.textContent = entities.length;

  // Entity list
  if (entities.length === 0) {
    entitiesList.innerHTML = `<p style="color:#00ff88;text-align:center;padding:10px;font-size:12px">✅ No PII detected!</p>`;
  } else {
    entitiesList.innerHTML = entities.map(e => `
      <div class="entity-item">
        <span class="entity-type">${e.entity_type}</span>
        <span class="entity-arrow">→</span>
        <span class="entity-masked">${e.masked_value}</span>
        <span class="entity-line">L${e.line || "?"}</span>
      </div>
    `).join("");
  }

  results.classList.remove("hidden");

  // Animate bars after DOM paint
  requestAnimationFrame(() => {
    document.querySelectorAll(".bd-bar[data-target]").forEach((bar, i) => {
      setTimeout(() => { bar.style.width = bar.dataset.target + "%"; }, 300 + i * 100);
    });
  });
}

// ── Loader helpers ─────────────────────────────────────────────────────────────
function showLoader(msg) {
  loaderText.textContent = msg || "Processing…";
  loader.classList.remove("hidden");
}
function hideLoader() {
  loader.classList.add("hidden");
}

// ── Init ───────────────────────────────────────────────────────────────────────
initGauge();
